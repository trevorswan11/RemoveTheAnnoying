# RemoveTheAnnoying
A very simple mod that removes the mineshaft interior, maneaters, and barbers from the game.

I have also noticed that players in the company cruiser at the end of the round can be considered 'missing' if the ship takes off when they are connected to the ships magnet. This has been a source of frustration in my runs, and this mod adds a config option to address it. The mod allows you to either teleport players in the cruiser to ship (consistent for only the driver), or simply mark them as in the ship 

There are available config options that can toggle the above features, and also allows blocking the facility/factor interior on Artifice. As much as I don't like playing with the barber and maneater, I know there might be some people only looking for certain parts of this mod, and the config options hope to address that :)

Artifice, in my opinion, deserves to have both facility AND manor, but sometimes I like to only play manor especially with my friends. That being said, it does also deserve to have more scrap, being an late-game, high-risk high-reward moon. This mod introduces a config option that allows users to revert the minimum and maximum scrap spawn on Artifice to its v56 levels. See the v1.3.0 Changelog for details!

Thanks so much for checking my mod out, and be sure to leave some feedback or check out some of my other projects on my GitHub!

This mod is compatible with AdiBTW's [Loadstone](https://thunderstore.io/c/lethal-company/p/AdiBTW/Loadstone/).

*Disclaimer: This mod was made for FUN only, and obviously wouldn't be used for official or competitive runs. Also, the icon used for this mod is AI generated.*