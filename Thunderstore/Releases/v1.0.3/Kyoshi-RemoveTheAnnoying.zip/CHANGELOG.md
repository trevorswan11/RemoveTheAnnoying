- **1.0.3**

    - Debugging Fixes
    - Code is marginally more readable
    - This release is not necessary for anything plugin related, but is more debugging/efficiency focused

- **1.0.2**

    - Small fixes, nothing changed plugin wise

- **1.0.1**

    - Fixed an issue that prevented you from landing on The Company Building

- **1.0.0**

    - Mod Release
