# RemoveTheAnnoying
Removes the mineshaft interior, maneaters, and barbers from the game.
