- **1.1.1**

    - Fixed spelling issue in config
    - Updated source code comments

- **1.1.0**

    - Added config options for disabling mineshaft and barber/maneater spawns
        - You can now toggle the spawning of Barbers and Maneaters
        - The mineshaft can be allowed if desired, but like why lol
        - All Config options are independent of each other, they will not do anything silly if different combinations are used
    - Added a new feature that prevents Facility generation on Artifice. This is a feature OFF BY DEFAULT, and can be toggled in the config
    - Other minor refactoring
    
    *Note: Config options DO NOT update midgame and DO require a restart upon changing*

    Thanks to [Jaexyr](https://github.com/Jaexyr) for the config suggestion!

- **1.0.3**

    - Debugging Fixes
    - Code is marginally more readable
    - This release is not necessary for anything plugin related, but is more debugging/efficiency focused

- **1.0.2**

    - Small fixes, nothing changed plugin wise

- **1.0.1**

    - Fixed an issue that prevented you from landing on The Company Building

- **1.0.0**

    - Mod Release
