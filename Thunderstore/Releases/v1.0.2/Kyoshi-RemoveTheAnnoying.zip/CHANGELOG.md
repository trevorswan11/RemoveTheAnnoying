- **1.0.2**

    - Small fixes, nothing changed plugin wise

- **1.0.1**

    - Fixed an issue that prevented you from landing on The Company Building

- **1.0.0**

    - Mod Release
